package com.example.pepcoder;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class AboutIt extends AppCompatActivity
{
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.aboutit);
    }
}
